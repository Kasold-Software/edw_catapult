# EDW Catapult
EDW Catapult is a CLI tool to automate the deployment of the <a href="http://www.datawarehouseetlframework.com/">Mass Street Analytics Data Warehouse ETL Framework</a>.
